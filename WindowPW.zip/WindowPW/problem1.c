#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

int main() {
	char str[80];
	char str_backup3[80];
	char str_backup4[80];
	int backup3 = 0;
	int backup4 = 0;
	char command;
	int i;
	int j;
	int temp;
	int S_alphabet[26] = { 0, };
	int L_alphabet[26] = { 0, };

	printf("Enter the sentense: ");
	gets(str);
	printf("%s\n", str);
	printf("command: ");
	command = getchar();
	while (command != '0')
	{
		if (command >= 'a' && command <= 'z') {
			for (i = 0; i < 80; i++) {
				if (command == str[i] + 32) {
					str[i] = command;
				}
				else if (command == str[i]) {
					str[i] = command - 32;
				}
				else if (str[i] == '.') {
					break;
				}
			}
			printf("%s\n", str);
		}
		else if (command >= 'A' && command <= 'Z') {
			for (i = 0; i < 80; i++) {
				if (command + 32 == str[i]) {
					str[i] = command;
				}
				else if (command == str[i]) {
					str[i] = command + 32;
				}
				else if (str[i] == '.') {
					break;
				}
			}
			printf("%s\n", str);
		}
		else if (command == '1') {
			
			printf("%s\n", str);
		}
		else if (command == '2') {
			printf("%s\n", str);
		}
		else if (command == '3') {
			if (backup3 == 0) {
				strcpy(str_backup3, str);
				
				removeSpaces
				for (i = 0; i < 80; i++) {
					for (j = 0; j < 80 - i - 1; j++) {
						if (str[j] >= 'a' && str[j] <= 'z') {
							if (str[j + 1] >= 'a' && str[j + 1] <= 'z') {
								if (str[j] > str[j + 1]) {
									temp = str[j];
									str[j] = str[j + 1];
									str[j + 1] = temp;
								}
							}
						}
						else if (str[j] >= 'A' && str[j] <= "Z") {
							temp = str[j];
							str[j] = str[j + 1];
							str[j + 1] = temp;
						}
					}
				}
				backup3 = 1;
			}
			else if (backup3 == 1) {
				strcpy(str, str_backup3);
				backup3 = 0;
			}
			printf("%s\n", str);
		}
		else if (command == '4') {
			printf("%s\n", str);
		}
		else if (command == '5') {
			for (i = 0; i < 80; i++) {
				if (str[i] >= 'a' && str[i] <= 'z') {
					S_alphabet[str[i] - 'a']++;
				} 
				else if (str[i] >= 'A' && str[i] <= 'Z') {
					L_alphabet[str[i] - 'A']++;
				}
				else if (str[i] == '.') {
					break;
				}
			}
			for (i = 0; i < 26; i++) {
				printf("%c: %d ", 'a' + i, S_alphabet[i]);
			}
			for (i = 0; i < 26; i++) {
				printf("%c: %d ", 'A' + i, L_alphabet[i]);
			}
			printf("\n");
		}
		printf("command: ");
		command = getchar();
	}

	return 0;
}